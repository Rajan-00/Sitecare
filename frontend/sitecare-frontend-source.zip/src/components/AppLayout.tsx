import { useState } from "react";
import {
  Activity,
  Bell,
  ChartNoAxesCombined,
  CircleGauge,
  Globe2,
  History,
  LogOut,
  Menu,
  Settings,
  ShieldCheck,
  Siren,
  UserRound,
  Wrench,
  X,
  type LucideIcon,
} from "lucide-react";
import {
  NavLink,
  Outlet,
  useLocation,
  useNavigate,
} from "react-router-dom";

import { useAuth } from "../context/AuthContext";

import "./AppLayout.css";

interface NavigationItem {
  label: string;
  path: string;
  icon: LucideIcon;
  end?: boolean;
}

const navigationItems: NavigationItem[] = [
  {
    label: "Overview",
    path: "/",
    icon: CircleGauge,
    end: true,
  },
  {
    label: "Websites",
    path: "/websites",
    icon: Globe2,
  },
  {
    label: "Incidents",
    path: "/incidents",
    icon: Siren,
  },
  {
    label: "Performance",
    path: "/anomalies",
    icon: Activity,
  },
  {
    label: "Maintenance",
    path: "/maintenance",
    icon: Wrench,
  },
  {
    label: "Analytics",
    path: "/analytics",
    icon: ChartNoAxesCombined,
  },
  {
    label: "Settings",
    path: "/settings",
    icon: Settings,
  },
  {
    label: "Activity",
    path: "/activity",
    icon: History,
  },
  {
    label: "Profile",
    path: "/profile",
    icon: UserRound,
  },
];

function getPageInformation(pathname: string): {
  title: string;
  description: string;
} {
  if (pathname === "/") {
    return {
      title: "Overview",
      description: "Website health and monitoring summary.",
    };
  }

  if (pathname.startsWith("/websites")) {
    return {
      title: "Websites",
      description: "Manage monitored websites and health checks.",
    };
  }

  if (pathname.startsWith("/incidents")) {
    return {
      title: "Incidents",
      description: "Review downtime events and recoveries.",
    };
  }

  if (pathname.startsWith("/anomalies")) {
    return {
      title: "Performance",
      description: "Review unusual response-time behaviour.",
    };
  }

  if (pathname.startsWith("/maintenance")) {
    return {
      title: "Maintenance",
      description: "Review website risk and maintenance recommendations.",
    };
  }

  if (pathname.startsWith("/analytics")) {
    return {
      title: "Analytics",
      description: "Explore uptime and response-time trends.",
    };
  }

  if (pathname.startsWith("/settings")) {
    return {
      title: "Settings",
      description: "Configure monitoring and notification preferences.",
    };
  }

  if (pathname.startsWith("/activity")) {
    return {
      title: "Activity",
      description: "Review recent account and monitoring actions.",
    };
  }

  if (pathname.startsWith("/profile")) {
    return {
      title: "Profile",
      description: "Manage your personal information and password.",
    };
  }

  if (pathname.startsWith("/notifications")) {
    return {
      title: "Notifications",
      description: "Review monitoring and account alerts.",
    };
  }

  return {
    title: "SiteCare",
    description: "Website monitoring platform.",
  };
}

export default function AppLayout() {
  const [sidebarOpen, setSidebarOpen] =
    useState(false);

  const location = useLocation();
  const navigate = useNavigate();
  const { user, logout } = useAuth();

  const pageInformation = getPageInformation(
    location.pathname,
  );

  const userInitial =
    user?.full_name?.trim().charAt(0).toUpperCase() ||
    "U";

  async function handleLogout(): Promise<void> {
    await logout();
    navigate("/login", { replace: true });
  }

  function closeSidebar(): void {
    setSidebarOpen(false);
  }

  return (
    <div className="app-layout">
      {sidebarOpen && (
        <button
          type="button"
          className="sidebar-overlay"
          aria-label="Close navigation"
          onClick={closeSidebar}
        />
      )}

      <aside
        className={
          sidebarOpen
            ? "app-sidebar app-sidebar-open"
            : "app-sidebar"
        }
      >
        <div className="sidebar-brand">
          <div className="sidebar-brand-icon">
            <ShieldCheck
              size={22}
              strokeWidth={2.2}
            />
          </div>

          <div className="sidebar-brand-text">
            <strong>SiteCare</strong>
            <span>Website monitoring</span>
          </div>

          <button
            type="button"
            className="sidebar-close-button"
            aria-label="Close navigation"
            onClick={closeSidebar}
          >
            <X size={20} />
          </button>
        </div>

        <div className="sidebar-workspace">
          <div className="sidebar-workspace-indicator">
            <span />
          </div>

          <div>
            <strong>All systems operational</strong>
            <span>Monitoring is running</span>
          </div>
        </div>

        <nav
          className="sidebar-navigation"
          aria-label="Main navigation"
        >
          <p className="sidebar-section-label">
            Workspace
          </p>

          {navigationItems.map(
            ({ label, path, icon: Icon, end }) => (
              <NavLink
                key={path}
                to={path}
                end={end}
                onClick={closeSidebar}
                className={({ isActive }) =>
                  isActive
                    ? "sidebar-link sidebar-link-active"
                    : "sidebar-link"
                }
              >
                <Icon
                  className="sidebar-link-icon"
                  size={18}
                  strokeWidth={1.9}
                />

                <span>{label}</span>
              </NavLink>
            ),
          )}
        </nav>

        <div className="sidebar-footer">
          <div className="sidebar-footer-account">
            <div className="sidebar-footer-avatar">
              {userInitial}
            </div>

            <div>
              <strong>
                {user?.full_name || "SiteCare User"}
              </strong>
              <span>{user?.email || "Account"}</span>
            </div>
          </div>

          <button
            type="button"
            className="sidebar-logout-button"
            onClick={handleLogout}
          >
            <LogOut size={17} />
            <span>Sign out</span>
          </button>
        </div>
      </aside>

      <div className="app-content">
        <header className="app-header">
          <div className="header-left">
            <button
              type="button"
              className="mobile-menu-button"
              aria-label="Open navigation"
              onClick={() => setSidebarOpen(true)}
            >
              <Menu size={21} />
            </button>

            <div className="header-title">
              <h1>{pageInformation.title}</h1>
              <p>{pageInformation.description}</p>
            </div>
          </div>

          <div className="header-actions">
            <NavLink
              to="/notifications"
              className={({ isActive }) =>
                isActive
                  ? "notification-button notification-button-active"
                  : "notification-button"
              }
              aria-label="Open notifications"
              title="Notifications"
            >
              <Bell size={19} />
            </NavLink>

            <NavLink
              to="/profile"
              aria-label="Open profile"
              className={({ isActive }) =>
                isActive
                  ? "header-profile header-profile-active"
                  : "header-profile"
              }
            >
              <div className="header-profile-avatar">
                {userInitial}
              </div>

              <div className="header-profile-details">
                <strong>
                  {user?.full_name || "SiteCare User"}
                </strong>
                <span>{user?.email || "Account"}</span>
              </div>
            </NavLink>
          </div>
        </header>

        <main className="app-main">
          <div className="app-main-content">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
}