export interface DashboardSummary {
  total_websites: number;
  active_websites: number;
  websites_up: number;
  websites_down: number;
  websites_not_checked: number;
  total_checks: number;
  total_incidents: number;
  overall_uptime_percentage: number;
  average_response_time_ms: number | null;
}

export type WebsiteStatus =
  | "up"
  | "down"
  | "not_checked";

export interface Website {
  id: number;
  name: string;
  url: string;
  check_interval_minutes: number;
  is_active: boolean;
  created_at: string;
}

export interface WebsiteCreate {
  name: string;
  url: string;
  check_interval_minutes: number;
}

export interface WebsiteUpdate {
  name?: string;
  url?: string;
  check_interval_minutes?: number;
  is_active?: boolean;
}

export interface MonitorCheck {
  id: number;
  website_id: number;
  status_code: number | null;
  response_time_ms: number | null;
  is_up: boolean;
  error_message: string | null;
  checked_url: string;
  checked_at: string;
  is_anomaly: boolean;
  anomaly_score: number | null;
  anomaly_reason: string | null;
}

export interface WebsiteStatusResponse {
  website_id: number;
  website_name: string;
  website_url: string;
  current_status: WebsiteStatus;
  latest_check: MonitorCheck | null;
}

export interface WebsiteMetric {
  website_id: number;
  website_name: string;
  website_url: string;
  is_active: boolean;
  current_status: WebsiteStatus;
  health_score: number;
  uptime_percentage: number;
  average_response_time_ms: number | null;
  total_checks: number;
  successful_checks: number;
  failed_checks: number;
  latest_status_code: number | null;
  last_checked_at: string | null;
}

export interface Incident {
  id: number;
  website_id: number;
  severity: "warning" | "critical";
  cause: string | null;
  first_status_code: number | null;
  latest_status_code: number | null;
  failure_count: number;
  is_resolved: boolean;
  started_at: string;
  resolved_at: string | null;
  duration_seconds: number | null;
}
export type MaintenanceRiskLevel =
  | "unknown"
  | "low"
  | "medium"
  | "high"
  | "critical";

export interface MaintenancePrediction {
  website_id: number;
  website_name: string;
  website_url: string;
  prediction_status: "learning" | "ready";
  risk_level: MaintenanceRiskLevel;
  risk_score: number;
  confidence_percentage: number;
  sample_count: number;
  current_average_response_time_ms: number | null;
  predicted_response_time_ms: number | null;
  response_time_trend_ms: number | null;
  failure_rate_percentage: number;
  anomaly_rate_percentage: number;
  recommendation: string;
}

export interface NotificationPreference {
  id: number;
  email_address: string;
  is_enabled: boolean;
  notify_on_downtime: boolean;
  notify_on_recovery: boolean;
  notify_on_anomaly: boolean;
  smtp_configured: boolean;
  created_at: string;
  updated_at: string;
}

export interface NotificationPreferenceUpdate {
  email_address: string;
  is_enabled: boolean;
  notify_on_downtime: boolean;
  notify_on_recovery: boolean;
  notify_on_anomaly: boolean;
}
export interface AuthUser {
  id: number;
  full_name: string;
  email: string;
  is_active: boolean;
  created_at: string;
}

export interface AccessTokenResponse {
  access_token: string;
  token_type: string;
  expires_in: number;
  user: AuthUser;
}

export interface RegisterPayload {
  full_name: string;
  email: string;
  password: string;
}