from fastapi import (
    APIRouter,
    Depends,
)

from app.api.dependencies import get_current_user
from app.api.routes import (
    account,
    audit_logs,
    in_app_notifications,
)
from app.api.routes.anomalies import (
    router as anomalies_router,
)
from app.api.routes.auth import (
    router as auth_router,
)
from app.api.routes.dashboard import (
    router as dashboard_router,
)
from app.api.routes.health import (
    router as health_router,
)
from app.api.routes.incidents import (
    router as incidents_router,
)
from app.api.routes.monitoring import (
    router as monitoring_router,
)
from app.api.routes.notifications import (
    router as notifications_router,
)
from app.api.routes.predictions import (
    router as predictions_router,
)
from app.api.routes.reports import (
    router as reports_router,
)
from app.api.routes.websites import (
    router as websites_router,
)

api_router = APIRouter()

# Public endpoints
api_router.include_router(
    health_router,
    tags=["Health"],
)

api_router.include_router(
    auth_router,
    prefix="/auth",
    tags=["Authentication"],
)

# These routers implement authentication on their own routes.
api_router.include_router(account.router)
api_router.include_router(audit_logs.router)

# Every router included here requires a valid JWT.
protected_router = APIRouter(
    dependencies=[Depends(get_current_user)],
)

protected_router.include_router(
    websites_router,
    prefix="/websites",
    tags=["Websites"],
)

protected_router.include_router(
    monitoring_router,
    prefix="/monitoring",
    tags=["Monitoring"],
)

protected_router.include_router(
    dashboard_router,
    prefix="/dashboard",
    tags=["Dashboard"],
)

protected_router.include_router(
    incidents_router,
    prefix="/incidents",
    tags=["Incidents"],
)

protected_router.include_router(
    anomalies_router,
    prefix="/anomalies",
    tags=["Anomalies"],
)

protected_router.include_router(
    predictions_router,
    prefix="/predictions",
    tags=["Maintenance Predictions"],
)

# Email notification settings.
protected_router.include_router(
    notifications_router,
    prefix="/notifications",
    tags=["Notifications"],
)

# In-app notification list, unread count and read actions.
# This router already defines prefix="/notifications/in-app".
protected_router.include_router(
    in_app_notifications.router,
)

protected_router.include_router(
    reports_router,
    prefix="/reports",
    tags=["Reports"],
)

api_router.include_router(protected_router)